import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class FileSearcher {
    // List to store paths of found files
    private static List<String> foundFiles = new ArrayList<>();
    // Counter to keep track of the number of files found
    private static int fileCount = 0;

    public static void main(String[] args) {
        // Check if at least the directory path and file name arguments are provided
        if (args.length < 2) {
            System.out.println("Usage: java FileSearcher <directory_path> <file_name> [case_sensitive]");
            return;
        }

        // Retrieve the directory path and file name from command-line arguments
        String directoryPath = args[0];
        String fileName = args[1];
        // Optional argument to specify case sensitivity (default is false if not provided)
        boolean caseSensitive = args.length > 2 && Boolean.parseBoolean(args[2]);

        // Start searching for the specified file
        searchFile(new File(directoryPath), fileName, caseSensitive);

        // Display search results
        if (foundFiles.isEmpty()) {
            System.out.println("File '" + fileName + "' not found in the directory.");
        } else {
            // Print each file path where the file was found
            for (String path : foundFiles) {
                System.out.println("File found: " + path);
            }
            // Display total count of occurrences
            System.out.println("Total occurrences of '" + fileName + "': " + fileCount);
        }
    }

    /**
     * Recursively searches for a file with a specified name in a directory.
     * 
     * @param dir The directory to search within.
     * @param fileName The name of the file to search for.
     * @param caseSensitive Whether the search should be case-sensitive.
     */
    public static void searchFile(File dir, String fileName, boolean caseSensitive) {
        // Get the list of files and directories in the current directory
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                // Check if the current file matches the target file name based on case sensitivity
                boolean found = caseSensitive ? file.getName().equals(fileName) : file.getName().equalsIgnoreCase(fileName);
                if (found) {
                    // If a match is found, add the file path to the list and increment the counter
                    foundFiles.add(file.getAbsolutePath());
                    fileCount++;
                }
                // If the current file is a directory, recursively search within it
                if (file.isDirectory()) {
                    searchFile(file, fileName, caseSensitive);
                }
            }
        }
    }

    /**
     * Helper method to create a test directory structure with sample files.
     * 
     * @param directoryPath The path where the test files should be created.
     */
    public static void createTestFiles(String directoryPath) {
        try {
            // Create the directory if it doesn't exist
            Path path = Paths.get(directoryPath);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }

            // Create several test files in the specified directory
            Files.createFile(Paths.get(directoryPath, "testFile1.txt"));
            Files.createFile(Paths.get(directoryPath, "testFile2.txt"));
            Files.createFile(Paths.get(directoryPath, "testFile3.txt"));
            Files.createFile(Paths.get(directoryPath, "Munazza.txt")); // Case-sensitive test file
            
            // Create a nested directory and add a test file inside it
            Path nestedDir = Paths.get(directoryPath, "nested");
            Files.createDirectories(nestedDir);
            Files.createFile(nestedDir.resolve("testFile4.txt"));
        } catch (IOException e) {
            // Display an error message if any issues occur during file creation
            System.err.println("Error creating test files: " + e.getMessage());
        }
    }
}
