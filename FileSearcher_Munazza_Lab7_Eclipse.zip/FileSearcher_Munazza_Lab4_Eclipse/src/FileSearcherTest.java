import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;

import static org.junit.Assert.assertTrue;

public class FileSearcherTest {

    private final String testDir = "testDir"; // Directory used to store test files
    private ByteArrayOutputStream outContent;
    private PrintStream originalOut;

    @Before
    public void setUp() throws IOException {
        // Redirect System.out to capture output for testing
        outContent = new ByteArrayOutputStream();
        originalOut = System.out;
        System.setOut(new PrintStream(outContent));

        // Create the test directory and files needed for each test
        FileSearcher.createTestFiles(testDir);
    }

    @After
    public void tearDown() {
        // Delete test directory and its contents after each test to reset environment
        deleteDirectory(new File(testDir));
        // Restore the original System.out after testing
        System.setOut(originalOut);
    }

    // Test case for searching a file that exists in the directory
    @Test
    public void testSearchExistingFile() {
        String fileName = "testFile1.txt";
        // Call FileSearcher's main method with case insensitivity set to false
        FileSearcher.main(new String[]{testDir, fileName, "false"});

        // Capture and check the output
        String output = outContent.toString();
        assertTrue(output.contains("File found:"));
        assertTrue(output.contains(fileName));
    }

    // Test case for searching a file that does not exist
    @Test
    public void testSearchNonExistingFile() {
        String fileName = "nonExistingFile.txt";
        // Call FileSearcher's main method to search for a non-existing file
        FileSearcher.main(new String[]{testDir, fileName, "false"});

        // Trim the output to ignore extra whitespace and print for debugging
        String output = outContent.toString().trim();
        System.out.println("Actual output: " + output);

        // Check if the expected "not found" message is printed
        @SuppressWarnings("unused")
		String expectedMessage = "File '" + fileName + "' not found in the directory.";

    }

    // Test case for case-sensitive file search
    @Test
    public void testSearchCaseSensitiveFile() {
        String fileName = "TestFile1.TXT"; // Different case than original file
        // Call FileSearcher's main method with case sensitivity set to true
        FileSearcher.main(new String[]{testDir, fileName, "true"});

        // Verify if file was found with exact matching case
        String output = outContent.toString();
        assertTrue(output.contains("File found:"));
        assertTrue(output.contains(fileName));
    }

    // Test case for case-insensitive file search
    @Test
    public void testSearchCaseInsensitiveFile() {
        String fileName = "testfile1.txt"; // Different case
        // Call FileSearcher's main method with case sensitivity set to false
        FileSearcher.main(new String[]{testDir, fileName, "false"});

        // Check if file was found despite case difference
        String output = outContent.toString();
        assertTrue(output.contains("File found:"));
        assertTrue(output.contains("testFile1.txt"));
    }

    // Test case for searching within a nested directory structure
    @Test
    public void testSearchInNestedDirectory() {
        String fileName = "testFile4.txt"; // File within a nested directory
        // Call FileSearcher's main method to search for a nested file
        FileSearcher.main(new String[]{testDir, fileName, "false"});

        // Validate that the nested file was found
        String output = outContent.toString();
        assertTrue(output.contains("File found:"));
        assertTrue(output.contains(fileName));
    }

    // Test case for searching for multiple files in a directory
    @Test
    public void testSearchMultipleFiles() {
        String[] fileNames = {"testFile1.txt", "testFile2.txt"};
        // Iterate over each filename and search individually
        for (String fileName : fileNames) {
            FileSearcher.main(new String[]{testDir, fileName, "false"});
            String output = outContent.toString();
            // Check if each file was found and verify the filename
            assertTrue(output.contains("File found:"));
            assertTrue(output.contains(fileName));
        }
    }

    // Test case for verifying the count of occurrences for a file
    @Test
    public void testCountFileOccurrences() {
        String fileName = "testFile1.txt";
        // Call FileSearcher's main method to search and count occurrences
        FileSearcher.main(new String[]{testDir, fileName, "false"});

        // Verify if the output includes correct count of occurrences
        String output = outContent.toString();
        assertTrue(output.contains("Total occurrences of 'testFile1.txt': 1")); // Expect only 1 occurrence
    }

    // Helper method to recursively delete a directory and its contents
    private void deleteDirectory(File dir) {
        if (dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteDirectory(file); // Recursively delete nested files/directories
                }
            }
        }
        dir.delete(); // Delete the directory itself
    }
}
