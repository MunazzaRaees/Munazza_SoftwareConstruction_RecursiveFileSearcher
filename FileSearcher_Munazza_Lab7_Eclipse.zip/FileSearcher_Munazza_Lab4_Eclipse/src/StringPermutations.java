import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class StringPermutations {

    // Main function to drive the program
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string to generate its permutations:");
        String input = scanner.nextLine();

        if (input.isEmpty()) {
            System.out.println("Error: Input string is empty.");
        } else {
            System.out.println("Include duplicates in permutations? (yes/no):");
            boolean includeDuplicates = scanner.nextLine().trim().equalsIgnoreCase("yes");

            List<String> permutations = generatePermutations(input, includeDuplicates);
            System.out.println("Permutations: " + permutations);
            System.out.println("Total Permutations: " + permutations.size());
        }
        scanner.close();
    }

    /**
     * Generates all permutations of a given string.
     *
     * @param str the input string
     * @param includeDuplicates if true, includes duplicate permutations
     * @return list of all permutations
     */
    public static List<String> generatePermutations(String str, boolean includeDuplicates) {
        List<String> permutations = new ArrayList<>();
        if (includeDuplicates) {
            generatePermutationsHelper(str, "", permutations);
        } else {
            Set<String> uniquePermutations = new HashSet<>();
            generatePermutationsHelper(str, "", uniquePermutations);
            permutations.addAll(uniquePermutations);
        }
        return permutations;
    }

    /**
     * Recursive helper function to generate permutations (with duplicates).
     *
     * @param str the remaining characters
     * @param prefix the current permutation prefix
     * @param permutations list to store permutations
     */
    private static void generatePermutationsHelper(String str, String prefix, List<String> permutations) {
        if (str.length() == 0) {
            permutations.add(prefix);
        } else {
            for (int i = 0; i < str.length(); i++) {
                String rem = str.substring(0, i) + str.substring(i + 1);
                generatePermutationsHelper(rem, prefix + str.charAt(i), permutations);
            }
        }
    }

    /**
     * Recursive helper function to generate unique permutations (no duplicates).
     *
     * @param str the remaining characters
     * @param prefix the current permutation prefix
     * @param uniquePermutations set to store unique permutations
     */
    private static void generatePermutationsHelper(String str, String prefix, Set<String> uniquePermutations) {
        if (str.length() == 0) {
            uniquePermutations.add(prefix);
        } else {
            for (int i = 0; i < str.length(); i++) {
                String rem = str.substring(0, i) + str.substring(i + 1);
                generatePermutationsHelper(rem, prefix + str.charAt(i), uniquePermutations);
            }
        }
    }
}
